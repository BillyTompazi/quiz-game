/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newquizgame;

import sun.management.resources.agent;

/**
 *
 * @author hp
 */
public class User {
    private String name, country;
    private int score,age;
    
    public User( String name,int age, String country,int score){
        
        this.name=name;
        this.age=age;
        this.country=country;
        this.score=score;   
        
    }
   
  
    public String getname(){
        return name;
    }
     public int getage(){
      return age;
    }
    public String getcountry(){
        return country;
    }
      public int getscore(){
        return score;
    }
    
}

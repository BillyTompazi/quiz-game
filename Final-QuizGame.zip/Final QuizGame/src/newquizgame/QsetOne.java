/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newquizgame;

/**
 *
 * @author hp
 */
public class QsetOne {
    
    
    
     private int qno;
    private String question,optiona,optionb,optionc,optiond;
    
    public QsetOne(String question,String optiona, String optionb,String optionc,String optiond){
    this.question=question;
    this.optiona=optiona;
    this.optionb=optionb;
    this.optionc=optionc;
    this.optiond=optiond;
    
}
    public String getquestion(){
    return question;
}
    public String getoptiona(){
    return optiona;
}
    public String getoptionb(){
    return optionb;
}
    public String getoptionc(){
    return optionc;
}
    public String getoptiond(){
    return optiond;
}
    
}
